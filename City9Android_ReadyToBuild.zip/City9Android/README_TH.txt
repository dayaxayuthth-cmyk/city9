เมืองท้องฟ้า 2 — โปรเจกต์ Android แบบออฟไลน์

สิ่งที่เตรียมไว้:
- เกม HTML อยู่ใน app/src/main/assets/index.html
- เปลี่ยน Three.js จาก CDN ให้เรียกไฟล์ในเครื่องชื่อ three.min.js
- WebView เปิด JavaScript และ DOM Storage เพื่อให้ระบบเซฟ localStorage ทำงาน
- ตอนสร้าง APK จะดาวน์โหลด Three.js r128 มาใส่ใน assets หากยังไม่มีไฟล์
- หลังสร้าง APK สำเร็จ ตัวเกมและไลบรารีจะอยู่ใน APK จึงเล่นได้โดยไม่ต้องมีเน็ต (ตราบใดที่เกมไม่มีทรัพยากรภายนอกอื่น)

ข้อจำกัดสำคัญ:
- นี่คือโปรเจกต์พร้อมนำไป build ไม่ใช่ไฟล์ APK ที่คอมไพล์เสร็จแล้ว
- ต้องใช้ Android SDK/Gradle/JDK ผ่านเครื่องมือพัฒนา Android ที่รองรับโปรเจกต์ Gradle บนโทรศัพท์ หรือคอมพิวเตอร์
- การ build ครั้งแรกต้องมีอินเทอร์เน็ตเพื่อดาวน์โหลด Gradle dependencies และ Three.js หากยังไม่มีไฟล์
- เซฟเกมเก็บในพื้นที่ข้อมูลของแอปผ่าน localStorage; ถ้าลบแอปหรือเคลียร์ข้อมูลแอป เซฟอาจหาย

สร้าง APK แบบ debug ด้วย Gradle:
  gradle assembleDebug
ไฟล์ผลลัพธ์จะอยู่ที่:
  app/build/outputs/apk/debug/app-debug.apk

ถ้าสร้างบนโทรศัพท์ ให้เปิดโฟลเดอร์โปรเจกต์นี้ในเครื่องมือ Android IDE ที่รองรับ Gradle project และติดตั้ง SDK/Build tools ตามที่เครื่องมือนั้นต้องการ
